package com.test.bill;

import java.util.ArrayList;
import java.util.List;


public class CostAdapter implements BillManager {

	static private List<Bill> texts = new ArrayList<Bill>();
   
	public List<Bill> arrayBill = new ArrayList<Bill>();
	public List<Person> arrayPerson = new ArrayList<Person>();
	public int id;
	
    public CostAdapter() {
    	
    }
    
    public ArrayList<Bill> getTexts()
    {
    	return (ArrayList<Bill>) texts;
    }

    public void setCostAndFood(String food, int cost)
    {
    	Bill bill = new Bill(food, cost, 0);
    	texts.add(bill);
    }
    
    public int getCount() {
        return 9;
    }

    public Object getItem(int position) {
        return null;
    }

    public long getItemId(int position) {
        return 0;
    }

    public boolean isEmpty()
    {
    	if(texts == null) return true;
    	else return false;
    }

	@Override
	public Integer getId() {
		
		return id;
	}

	@Override
	public void setTheBill() {
		Person person = new Person();
		arrayPerson.add(person);
		id = person.getID();
	}

	
	@Override
	public void getTheBill(String[] food, int[] cost) {
		for(int i = 0; i < food.length ; i++ )
		{
			Bill bill = new Bill(food[i],cost[i],id);
			arrayBill.add(bill);
		}
	}

	
  
}
