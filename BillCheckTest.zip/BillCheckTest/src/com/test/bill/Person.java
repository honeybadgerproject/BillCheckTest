package com.test.bill;

public class Person {

	static {
		id=0;
	}
	
	private static int id;
	
	
	Person()
	{
		id++;
	}
	
	
	public int getID()
	{
		return id;
	}
	
}
