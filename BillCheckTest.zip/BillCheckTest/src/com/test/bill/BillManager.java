package com.test.bill;


public interface BillManager {
	
	public Integer getId();

	public void setTheBill();
	
	public void getTheBill(String[] food, int[] cost);  
	
	
}
