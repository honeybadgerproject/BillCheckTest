package com.test.bill;

public class Bill {
	
	private String food;
	private Integer cost;
	private int idPerson;
	
	
	public Bill(String food, int cost, int idPerson)
	{
		this.food = food;
		this.cost = cost;
		this.idPerson = idPerson;
	}
	
		
	public String getFood()
	{
		return food;
	}
	
	
	public Integer getCost()
	{
		return cost;
	}
	
	public int getIdPerson()
	{
		return idPerson;
	}
	

}
