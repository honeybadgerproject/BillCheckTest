package com.test.billchecktest;


import org.honey.hbController.HoneyBadger;
import org.honey.hbController.SingleEntry;


import com.test.bill.BillManager;
import com.test.bill.CostAdapter;

import android.support.v7.app.ActionBarActivity;
import android.support.v4.app.Fragment;
import android.content.ContextWrapper;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class MainActivity extends ActionBarActivity {

	public BillManager billManager;
	Intent intentTest;
	static ContextWrapper contextWrapper;
	static ActionBarActivity action;
		
	 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
				
		TextView view = (TextView) findViewById(R.id.textView1);
				
		billManager = new CostAdapter(); 
		billManager.setTheBill();
		view.setText("Person #" + billManager.getId().toString());
		
		////***************Honey Badger call***************////
        HoneyBadger w_object = SingleEntry.getInstance();
        w_object.createMap(this,getAssets());
        ////***********************************************////
        
        contextWrapper = (ContextWrapper) getApplicationContext();
        action = this;
        
 

		if (savedInstanceState == null) {
			getSupportFragmentManager().beginTransaction()
					.add(R.id.container, new PlaceholderFragment()).commit();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	
	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main, container,
					false);
			return rootView;
		}
	}
	
	
	
	
	public void changeSetOneBillActivity()
	{
		System.out.println("-------- OneBillActivity -------");

		try {
	        Intent intent = new Intent(contextWrapper, OneBillActivity.class);
	        action.startActivity(intent);
	    } catch (NullPointerException ex) {

	    	Log.e(null, "Error activity");
	    }	
	}
	
	public void changeBillViewActivity()
	{
		System.out.println("-------- BillViewActivity -------");

		try {
	        Intent intent = new Intent(contextWrapper, BillViewActivity.class);
	        action.startActivity(intent);
	    } catch (NullPointerException ex) {

	    	Log.e(null, "Error activity");
	    }	
	}


}
