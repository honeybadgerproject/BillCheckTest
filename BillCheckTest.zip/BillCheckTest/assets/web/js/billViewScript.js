var x="algo";
var y=4;

$(document).ready(function() {
    $(".addFood").click(function() {
    	
    	var x = document.getElementById("fieldFood").value;
		var y = document.getElementById("fieldCost").value;
		
    	 window.MyView.addFood(x , y);
    });
    
});
